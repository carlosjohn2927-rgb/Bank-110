<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Sign in · NorthWest Financial</title>
<?=render_seo_meta('Admin sign in')?>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="icon" href="<?=base_url('public/favicon.svg')?>" type="image/svg+xml">
<link rel="alternate icon" href="<?=base_url('public/favicon.ico')?>" sizes="any">
<link rel="stylesheet" href="<?=base_url('public/css/app.css')?>">
</head>
<body class="auth">
<?=render_announcement()?>
<section>
  <div class="auth-top">
    <?=render_language_switcher('lang-switch auth-lang')?>
    <a class="brand" href="<?=site_url('/')?>"><i><b></b><b></b><b></b></i>North<span>West</span></a>
    <a href="<?=site_url('user/login')?>">Personal banking ›</a>
  </div>
  <div class="auth-card">
    <em>SECURE ADMIN PORTAL</em>
    <h1>Welcome back, Admin</h1>
    <p>Enter your administrator credentials to continue.</p>
    <?=form_open('login')?>
      <label>Email or username</label>
      <input name="identity" required autofocus placeholder="Enter email or username" autocomplete="username">
      <label>Password</label>
      <input name="password" type="password" required placeholder="Enter password" autocomplete="current-password">
      <?php if($this->session->flashdata('error')):?><div class="form-error"><?=$this->session->flashdata('error')?></div><?php endif?>
      <button class="btn wide">Sign in securely ›</button>
    </form>
    <div class="security-note">✓ <span><b>Restricted access</b><br>All administrative actions are securely audited.</span></div>
  </div>
  <footer>© 2026 NorthWest Financial Ltd. · <a href="<?=site_url('/')?>">Home</a> · <a href="<?=site_url('user/login')?>">Customer sign in</a></footer>
</section>
<aside class="auth-image admin-image">
  <div>
    <span>✓ Operations secured</span>
    <h2>Banking control.<br>One clear view.</h2>
    <p>Manage customers and financial operations through a protected administration environment.</p>
  </div>
</aside>
<?=render_chat_widget()?>
</body>
</html>
