<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign in · NorthWest Financial</title>
<?=render_seo_meta('Sign in')?>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?=base_url('public/css/app.css')?>">
</head>
<body class="auth">
<?=render_announcement()?>
<section>
  <div class="auth-top">
    <?=render_language_switcher('lang-switch auth-lang')?>
    <a class="brand" href="<?=site_url('/')?>"><i><b></b><b></b><b></b></i>North<span>West</span></a>
    <a href="<?=site_url('login')?>">Administrator login ›</a>
  </div>
  <div class="auth-card">
    <em>ONLINE BANKING</em>
    <h1>Welcome to NorthWest</h1>
    <?php $credentials = $this->input->get('credentials') && $this->session->userdata('captcha_verified'); ?>
    <?php if (!$credentials): ?>
      <p>Please confirm you are not a robot by verifying the auto-generated code below.</p>
      <div class="captcha"><strong><?=implode(' ', str_split($captcha))?></strong><button onclick="location.reload()">↻</button></div>
      <?=form_open('verify')?>
        <label>Verification code</label>
        <input name="code" inputmode="numeric" required autofocus placeholder="Enter the code shown above">
        <?php if ($this->session->flashdata('error')): ?><div class="form-error"><?=$this->session->flashdata('error')?></div><?php endif ?>
        <button class="btn wide">Verify code ›</button>
      </form>
    <?php else: ?>
      <p>Enter your secure login details to access your account.</p>
      <?=form_open('auth/customer_login')?>
        <label>Account number or email</label>
        <input name="identity" required autofocus placeholder="Enter your account ID" autocomplete="username">
        <label>Password</label>
        <input name="password" type="password" required placeholder="Enter your password" autocomplete="current-password">
        <?php if ($this->session->flashdata('error')): ?><div class="form-error"><?=$this->session->flashdata('error')?></div><?php endif ?>
        <button class="btn wide">Sign in securely ›</button>
        <a class="forgot-link" href="<?=site_url('forgot')?>">Forgot your password?</a>
        <p class="register-link">New to NorthWest? <a href="<?=site_url('register')?>">Create an account</a></p>
      </form>
    <?php endif ?>
    <div class="security-note">✓ <span><b>Your security matters</b><br>Industry-standard encryption protects your information.</span></div>
  </div>
  <footer>© 2026 NorthWest Financial Ltd. · <a href="<?=site_url('/')?>">Home</a> · <a href="<?=site_url('login')?>">Admin</a></footer>
</section>
<aside class="auth-image">
  <div>
    <span>✓ Banking made safer</span>
    <h2>Your money.<br>Moving forward.</h2>
    <p>Simple, secure banking designed around the way you live and work.</p>
    <hr>
    <b>256-bit<small> encryption</small></b>
    <b>24/7<small> monitoring</small></b>
    <b>100%<small> protected</small></b>
  </div>
</aside>
<?=render_chat_widget()?>
</body>
</html>
