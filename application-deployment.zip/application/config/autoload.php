<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'session', 'form_validation', 'pagination');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'form', 'security', 'number', 'northwest', 'notification');
$autoload['config'] = array('northwest');
$autoload['language'] = array();
$autoload['model'] = array('Bank_model');
